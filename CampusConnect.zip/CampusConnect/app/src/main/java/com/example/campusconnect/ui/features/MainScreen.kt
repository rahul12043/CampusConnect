package com.example.campusconnect.ui.features

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.*
import com.example.campusconnect.navigation.Screen
import com.example.campusconnect.ui.features.digitalqueue.CafeteriaMenuScreen
import com.example.campusconnect.ui.features.lostandfound.LostAndFoundScreen
import com.example.campusconnect.ui.features.lostandfound.ReportItemScreen
import com.example.campusconnect.ui.features.utility.*
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(onLogout: () -> Unit) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    // --- FIX: Dynamic Title Logic ---
    val title = when (currentRoute) {
        Screen.Home.route -> "Campus Connect+"
        Screen.DigitalQueue.route -> "Cafeteria Menu"
        Screen.LostAndFound.route -> "Lost & Found"
        Screen.ReportLostFoundItem.route -> "Report an Item"
        Screen.MindMingle.route -> "Mind Mingle"
        Screen.PeerSkill.route -> "PeerSkill Hub"
        Screen.IdeaIncubator.route -> "Idea Incubator"
        Screen.FacultyConnect.route -> "Faculty Connect"
        else -> "Campus Connect+" // Default fallback
    }

    Scaffold(
        topBar = {
            TopAppBar(
                // The title now changes based on the current screen
                title = { Text(title) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                ),
                navigationIcon = {
                    if (currentRoute != Screen.Home.route) {
                        IconButton(onClick = { navController.navigateUp() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = MaterialTheme.colorScheme.onPrimary)
                        }
                    }
                },
                actions = {
                    IconButton(onClick = {
                        Firebase.auth.signOut()
                        onLogout()
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ExitToApp, "Logout", tint = MaterialTheme.colorScheme.onPrimary)
                    }
                }
            )
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) { HomeScreen(navController = navController) }
            composable(Screen.DigitalQueue.route) { CafeteriaMenuScreen() }
            composable(Screen.LostAndFound.route) { LostAndFoundScreen(navController = navController) }
            composable(Screen.ReportLostFoundItem.route) {
                ReportItemScreen(onItemReported = { navController.popBackStack() })
            }
            composable(Screen.MindMingle.route) { MindMingleScreen(navController) }
            composable(Screen.PeerSkill.route) { PeerSkillScreen(navController) }
            composable(Screen.IdeaIncubator.route) { IdeaIncubatorScreen(navController) }
            composable(Screen.FacultyConnect.route) { FacultyConnectScreen(navController) }
        }
    }
}