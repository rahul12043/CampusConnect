package com.example.campusconnect.ui.features.lostandfound_admin

import androidx.lifecycle.ViewModel
import com.example.campusconnect.data.LostFoundItem
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

// FIX: Renamed to be unique
data class AdminLostFoundState(
    val pendingItems: List<LostFoundItem> = emptyList(),
    val isLoading: Boolean = true
)

// FIX: Renamed to be unique
class LostAndFoundAdminViewModel : ViewModel() {
    private val firestore = Firebase.firestore
    private val _state = MutableStateFlow(AdminLostFoundState())
    val state = _state.asStateFlow()

    init {
        firestore.collection("lostAndFoundItems")
            .whereEqualTo("status", "PENDING_REVIEW")
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshots, error ->
                if (error != null) {
                    _state.value = _state.value.copy(isLoading = false)
                    return@addSnapshotListener
                }
                val items = snapshots?.toObjects(LostFoundItem::class.java) ?: emptyList()
                _state.value = AdminLostFoundState(pendingItems = items, isLoading = false)
            }
    }

    fun updateItemStatus(itemId: String, newStatus: String) {
        if (itemId.isNotBlank()) {
            firestore.collection("lostAndFoundItems").document(itemId)
                .update("status", newStatus)
        }
    }
}