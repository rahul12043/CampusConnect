package com.example.campusconnect.ui.features.lostandfound

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.campusconnect.data.LostFoundItem
import com.google.firebase.Timestamp
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.ktx.storage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.UUID

data class LostFoundState(
    val items: List<LostFoundItem> = emptyList(),
    val isLoading: Boolean = true,
    val isSubmitting: Boolean = false // NEW: To track submission progress
)

class LostAndFoundViewModel : ViewModel() {
    private val firestore = Firebase.firestore
    private val storage = Firebase.storage
    private val auth = Firebase.auth

    private val _state = MutableStateFlow(LostFoundState())
    val state = _state.asStateFlow()

    init {
        // Listen for real-time updates on ACTIVE items only
        firestore.collection("lostAndFoundItems")
            .whereEqualTo("status", "ACTIVE")
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshots, error ->
                if (error != null) {
                    _state.value = _state.value.copy(isLoading = false)
                    return@addSnapshotListener
                }
                val items = snapshots?.toObjects(LostFoundItem::class.java) ?: emptyList()
                _state.value = _state.value.copy(items = items, isLoading = false)
            }
    }

    // --- FIX: This function signature is now correct ---
    fun reportItem(
        name: String,
        description: String?, // Nullable for optional field
        location: String,
        imageUri: Uri?,
        onComplete: (Boolean) -> Unit
    ) {
        val userId = auth.currentUser?.uid ?: return onComplete(false)
        _state.value = _state.value.copy(isSubmitting = true) // Use the new progress state

        viewModelScope.launch {
            try {
                var imageUrl: String? = null
                // 1. Upload image to Cloud Storage if one is selected
                if (imageUri != null) {
                    val fileName = "lost_and_found/${UUID.randomUUID()}.jpg"
                    val storageRef = storage.reference.child(fileName)
                    storageRef.putFile(imageUri).await()
                    imageUrl = storageRef.downloadUrl.await().toString()
                }

                // 2. Create a document in Firestore
                val document = firestore.collection("lostAndFoundItems").document()
                val newItem = LostFoundItem(
                    id = document.id,
                    name = name,
                    description = description,
                    location = location,
                    status = "PENDING_REVIEW", // All new items must be reviewed
                    reporterId = userId,
                    imageUrl = imageUrl,
                    timestamp = Timestamp.now()
                )
                document.set(newItem).await()
                onComplete(true)
            } catch (e: Exception) {
                e.printStackTrace()
                onComplete(false)
            } finally {
                _state.value = _state.value.copy(isSubmitting = false)
            }
        }
    }
}