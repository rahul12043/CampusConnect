package com.example.campusconnect.ui.features.cafeteria_staff

import androidx.lifecycle.ViewModel
import com.example.campusconnect.data.Order
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update // Important import

data class StaffState(
    val newOrders: List<Order> = emptyList(),
    val preparingOrders: List<Order> = emptyList(),
    val isLoading: Boolean = true
)

class CafeteriaStaffViewModel : ViewModel() {
    private val firestore = Firebase.firestore
    private val _state = MutableStateFlow(StaffState())
    val state = _state.asStateFlow()

    init {
        listenForNewOrders()
        listenForPreparingOrders()
    }

    private fun listenForNewOrders() {
        firestore.collection("orders")
            .whereEqualTo("status", "PLACED")
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .addSnapshotListener { value, error ->
                if (error != null) {
                    _state.update { it.copy(isLoading = false) }
                    return@addSnapshotListener
                }
                val orders = value?.toObjects(Order::class.java) ?: emptyList()
                // --- FIX: Use .update to prevent overwriting state ---
                _state.update { currentState ->
                    currentState.copy(newOrders = orders, isLoading = false)
                }
            }
    }

    private fun listenForPreparingOrders() {
        firestore.collection("orders")
            .whereEqualTo("status", "PREPARING")
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .addSnapshotListener { value, error ->
                if (error != null) {
                    _state.update { it.copy(isLoading = false) }
                    return@addSnapshotListener
                }
                val orders = value?.toObjects(Order::class.java) ?: emptyList()
                // --- FIX: Use .update to prevent overwriting state ---
                _state.update { currentState ->
                    currentState.copy(preparingOrders = orders, isLoading = false)
                }
            }
    }

    fun updateOrderStatus(orderId: String, newStatus: String) {
        if (orderId.isNotBlank()) {
            firestore.collection("orders").document(orderId).update("status", newStatus)
        }
    }
}