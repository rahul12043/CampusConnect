package com.example.campusconnect.navigation

sealed class Screen(val route: String) {
    data object Login : Screen("login_screen")
    data object Register : Screen("register_screen")
    data object Home : Screen("home_screen")
    data object DigitalQueue : Screen("digital_queue_screen")
    data object LostAndFound : Screen("lost_and_found_screen")
    data object MindMingle : Screen("mind_mingle_screen")
    data object PeerSkill : Screen("peer_skill_screen")
    data object IdeaIncubator : Screen("idea_incubator_screen")
    data object FacultyConnect : Screen("faculty_connect_screen")
    data object ReportLostFoundItem : Screen("report_lost_found_item")
}